# -*- coding: utf-8 -*-

from odoo import models, fields, api


# create another class(db) for breakdown calculation
class HsAmount(models.Model):
    _name = 'import.product'
    _description = 'Import amount breakdown'
    # _rec_name = 'product_name'

    # id=fields.Integer(string="ID",stored=True, required=False)
    po_no = fields.Char(string="PO Name")
    po_line_id = fields.Integer(string="Purchase Line ID", required=True)
    product_name = fields.Char(string="Product")
    hs_code_name = fields.Char(string="HS Code")
    line_computation = fields.One2many('import.product.line', 'import_product', string='Expenses')

    # default get method for getting value from database and load into wizard form (gridview/add a line)
    @api.model
    def default_get(self, fields):
        varhscodeid = str(self._context['hscode_id'])
        varimportcodeid = str(self._context['hscode_id'])
        varpurchaseorderid = str(self._context['current_id'])
        # vproductname = str(self._context['product_id'])
        res = super(HsAmount, self).default_get(fields)
        line_computation = []
        product_rec = self.env['import.line'].search([('code_name', '=', varhscodeid)])
        pimportid = self.env['import.code'].search([('id', '=', varimportcodeid)])
        phscode = self.env['purchase.order'].search([('id', '=', varpurchaseorderid)])
        # hsproductname = self.env['product.template'].search([('id', '=', vproductname)])
        # product_po = self.env['purchase.order'].search([('id', '=', varpo)])
        for pro in product_rec:
            hsproductname = self.env['product.product'].search([('id', '=', pro.import_product_id.id)])
            line = (0, 0, {
                'po_no': phscode[0]['name'],
                'hs_code_line': pimportid[0]['code_name'],
                'service_name': hsproductname[0]['name'],
                'hs_type': pro.expense_type,
                'hs_value': pro.expense_value,
                'hs_amount': pro.expense_amount,

            })
            line_computation.append(line)
        res.update({
            'line_computation': line_computation,
            # 'product_name': 'maaz'
        })
        return res

    # end code of default method

    # method:value getting from database and load into wizard form (header)
    @api.onchange('po_no')
    def compute_hscode(self):
        varhscid = str(self._context['hscode_id'])
        icode = self.env['import.code'].search_read([('id', '=', varhscid)])
        vpnoid = self._context['current_id']
        ipno = self.env['purchase.order'].search_read([('id', '=', vpnoid)])
        self.po_no = ipno[0]['name']
        self.po_line_id = self._context['product_id']
        self.product_name = self._context['product_name']
        self.hs_code_name = icode[0]['code_name']
    # end code of method:value getting


# end class of HsAmount:breakdown calculation
# create another class of HSRelation for loading value from another class:import.product
class HsRelation(models.Model):
    _name = 'import.product.line'
    _description = 'Import line breakdown'
    # inherit class code
    # _inherit=['import.line', 'import.code']

    po_no = fields.Char(string="Name")
    import_product = fields.Many2one('import.product', string="ID")
    hs_code_line = fields.Char(string="HS Code")
    service_name = fields.Char(string="Service")
    hs_type = fields.Char(string='Type')
    hs_value = fields.Float(string='Value')
    hs_amount = fields.Float(string='Amount', readonly=True)


# end class HsRelation
# create another class for HSCodline:for import line class for added value in hs code
class HsCodeLine(models.Model):
    _name = 'import.line'
    _description = 'Line Master'

    expense_type = fields.Selection(selection=[('amount', 'Amount'), ('percentage', 'Percentage')],
                                    string='Type', defauilt='amount')
    expense_value = fields.Float(string='Value')
    import_product_id = fields.Many2one('product.product', string='Name', stored=True, required=False)
    expense_amount = fields.Float(string='Amount', readonly=True)
    code_name = fields.Char(string='Name', required=True)


# end class HsCodeLine
# create another class : HsCode for HScode master data
class HsCode(models.Model):
    _name = 'import.code'
    _description = 'HSCode Master Data'
    _rec_name = 'code_name'

    code_name = fields.Char(string='Name', required=True)
    code_expenses = fields.One2many('import.line', 'code_name', string='Expenses')

    # method for geting name from another class
    # @api.model
    # def create(self, values):
    #     print("function value", values)
    #     print("Self", self)
    #     nam = super(HsCode, self).create(values)
    #     print("Return value", nam)
    #     return nam
    # end create method


# create class for inherit :ProductTemplateInherit:from product.template
class ProductTemplateInherit(models.Model):
    _inherit = 'product.template'

    hsNumber = fields.Many2one('import.code', string='HsCode')


# end class
# create class for inherit :PurchaseOrderInherit:from purchase.order.line and also have code for calcuating value and amount of each hs code items
class PurchaseOrderInherit(models.Model):
    _inherit = 'purchase.order.line'

    # def open_wizard(self):
    #     return {
    #         'name': self.name,
    #         'res_model': 'purchase.order',
    #         'type': 'ir.actions.act_window',
    #         'context': {'current_id': self.id},
    #         'view_mode': 'form',
    #         'view_type': 'form',
    #         'target': 'new'
    #     }

    #amount calculation
    def compute_calculation(self):
        for rec in self:
            for line in rec:
                varcalculate = rec.product_qty * rec.price_unit
                rec.amount=varcalculate
    #end

    # compute function button
    # button code here
    # def compute_hscode(self):
    #     pass

    # def compute_hscode(self):
    #     return {
    #         'name': "Your String",
    #         'type': 'ir.actions.act_window',
    #         'view_type': 'form',
    #         'view_mode': 'form',
    #         'res_model': 'import.product',
    #         'view_id': self.env.ref('abs_HS.import.product').id,
    #         'target': 'new'
    #     }

    # method for clicking button onchange
    @api.onchange('product_id')
    def set_hs_code(self):
        for rec in self:
            if rec.product_id:
                rec.hsNumber = rec.product_id.hsNumber

    # end code
    # method for price unit and hs code when tab pressing
    @api.onchange('hsNumber', 'price_unit')
    def set_total_exp(self):
        # self.amount = 1
        total_value = []
        exp_type = []

        per_index_arr = []
        amo_index_arr = []

        per_arr = []
        amo_arr = []

        per_sum_arr = []
        amo_sum_arr = []
        # self.amount = 100

        # # amount method
        # for rec in self:
        #     self.amount = self.price_subtotal
        # # if rec.product_id:
        # #     rec.hsNumber=rec.product_id.hsNumber
        # #     for line in rec.hsNumber.code_expenses:
        #
        # # end amount method
        for rec in self:
            if rec.product_id:
                rec.hsNumber = rec.product_id.hsNumber
                for line in rec.hsNumber.code_expenses:
                    total_value.append(line.expense_value)
                    exp_type.append(line.expense_type)

        ## Separating percentage values
        if len(total_value) == len(exp_type):
            for i in range(len(total_value)):
                if exp_type[i] == 'percentage':
                    per_index_arr.append(i)
                    for j in range(len(per_index_arr) + 1):
                        if i == j:
                            per_arr.append(total_value[j])
                else:
                    # exp_type[i] == 'amount':
                    print(i)
                    amo_index_arr.append(i)
                    for j in range(len(amo_index_arr) + 1):
                        if j == i:
                            amo_arr.append(total_value[j])

        for i in range(len(per_arr)):
            var = per_arr[i]
            var = (var / 100) * self.price_subtotal
            per_sum_arr.append(var)

            ##-------END-------##

        self.amount = sum(per_sum_arr) + sum(amo_arr)
        print(exp_type, total_value)
        for rec in self:
            for line in rec.hsNumber.code_expenses:
                line.expense_amount = self.amount
                #print(self.amount)

            # code for subtotal and percentage
            print(exp_type, total_value)
            for rec in self:
                for line in rec.hsNumber.code_expenses:
                    if line.expense_type == 'percentage':
                        var = line.expense_value
                        line.expense_amount = (var / 100) * rec.price_subtotal
                    else:
                        line.expense_amount = line.expense_value
            # end code
            # HsAmount.compute_hscode(total_value)

    # end code for hscode, price unit when tab pressing
    # method for onchange when pressing product_qty, or price unit and few calculation is done in this method
    @api.depends('hsNumber')
    @api.onchange('product_qty', 'price_unit')
    def qty_change(self):
        # self.amount = 1
        total_value = []
        exp_type = []

        per_index_arr = []
        amo_index_arr = []

        per_arr = []
        amo_arr = []

        per_sum_arr = []
        amo_sum_arr = []

        for rec in self:
            if rec.product_id:
                rec.hsNumber = rec.product_id.hsNumber
                for line in rec.hsNumber.code_expenses:
                    total_value.append(line.expense_value)
                    exp_type.append(line.expense_type)

        ## Separating percentage values
        if len(total_value) == len(exp_type):
            for i in range(len(total_value)):
                if exp_type[i] == 'percentage':
                    per_index_arr.append(i)
                    for j in range(len(per_index_arr) + 1):
                        if i == j:
                            per_arr.append(total_value[j])
                else:
                    # exp_type[i] == 'amount':
                    amo_index_arr.append(i)
                    for j in range(len(amo_index_arr) + 1):
                        if j == i:
                            print(i)
                            amo_arr.append(total_value[j])


        for rec in self:
            for i in range(len(per_arr)):
                var = per_arr[i]
                var = (var / 100) * self.price_subtotal
                per_sum_arr.append(var)

            ##-------END-------##

        # self.amount = sum(per_sum_arr) + sum(amo_arr)
        self.amount = 500
        print(exp_type, total_value)

    # end code when pressing product_qty, or price unit
    # extension of purchase order line
    hsNumber = fields.Many2one('import.code', string='HsCode')
    amount = fields.Float(string='Amount', readonly=True, compute='compute_calculation')
    # end extension of PO line
    #,
# end class PurchaseOrderInherit
